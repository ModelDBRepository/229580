simFn = '../../data/sweep_random/output/er_n300_k1.5_deg_pI0.20_rep3.mat'
outFn='../tmp.mat'
binWidth = 40
fSigma = 20
spikeThresh = -20
secFlag = False
trans = 40e3


./doPost.
