prebotc-graph-model/postprocessing
==================================

Sequence of steps:

1. doPost.py - run on the .mat output of the model, generates another .mat file
2. collectPostOutput.py - aggregate the postprocessed output
3. doPlots.m - make various output figures

