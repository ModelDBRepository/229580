double infHN( double A, double B, double V );
double tau( double A, double B, double C, double V );
double phi( double x, double kNa );
